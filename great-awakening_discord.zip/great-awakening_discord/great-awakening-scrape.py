#INSTALL SELENIUM BEFORE RUNNING THIS CODE
# python3 ur_scrape.py
#pip3 install selenium
import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time
import getpass
from selenium.common.exceptions import NoSuchElementException

#IF USING A RASPBERRY PI, FIRST INSTALL THIS OPTIMIZED CHROME DRIVER
#sudo apt-get install chromium-chromedriver
browser_driver = Service('/lib/chromium-browser/chromedriver')
page_to_scrape = webdriver.Chrome(service=browser_driver)
url = "https://discordleaks.unicornriot.ninja/discord/channel/1245"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_start-here.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#2
url = "https://discordleaks.unicornriot.ninja/discord/channel/1246"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_daily-push.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#3
url = "https://discordleaks.unicornriot.ninja/discord/channel/1247"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_meme-masterpieces.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#4
url = "https://discordleaks.unicornriot.ninja/discord/channel/1249"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_uk-brexit-chat.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#5
url = "https://discordleaks.unicornriot.ninja/discord/channel/1250"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_healthy-options.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#6
url = "https://discordleaks.unicornriot.ninja/discord/channel/1251"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_2nd-amend-appreciation.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#7
url = "https://discordleaks.unicornriot.ninja/discord/channel/1252"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_prayer-room.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#8
url = "https://discordleaks.unicornriot.ninja/discord/channel/1253"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_cnd-united.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#9
url = "https://discordleaks.unicornriot.ninja/discord/channel/1254"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_eu-yellow-vest.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#10
url = "https://discordleaks.unicornriot.ninja/discord/channel/1255"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_religious-text.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#11
url = "https://discordleaks.unicornriot.ninja/discord/channel/1256"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_dustin-nemos-updates.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#12
url = "https://discordleaks.unicornriot.ninja/discord/channel/1257"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_petitions.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#13
url = "https://discordleaks.unicornriot.ninja/discord/channel/1258"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_research-open.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#14
url = "https://discordleaks.unicornriot.ninja/discord/channel/1259"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_q-drops-only.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#15
url = "https://discordleaks.unicornriot.ninja/discord/channel/1260"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_qanon-documents-chat.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#16
url = "https://discordleaks.unicornriot.ninja/discord/channel/1261"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_q-proofs.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#17
url = "https://discordleaks.unicornriot.ninja/discord/channel/1262"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_qnetworkingandbusiness.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#18
url = "https://discordleaks.unicornriot.ninja/discord/channel/1263"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_cryptocurrency-chat.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#19
url = "https://discordleaks.unicornriot.ninja/discord/channel/1264"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_pedogate-research.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#20
url = "https://discordleaks.unicornriot.ninja/discord/channel/1265"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_pedoperps-trello-archive-project.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#21
url = "https://discordleaks.unicornriot.ninja/discord/channel/1266"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_space-talk.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#22
url = "https://discordleaks.unicornriot.ninja/discord/channel/1267"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_flat-earth-theory.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#23
url = "https://discordleaks.unicornriot.ninja/discord/channel/2233"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_movies-music-books.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
#24
url = "https://discordleaks.unicornriot.ninja/discord/channel/2234"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_q-drops-public.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()

url = "https://discordleaks.unicornriot.ninja/discord/channel/2728"
page_to_scrape.get(url)

user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
for link in links:
    link.get_attribute("href")
file = open("great-awakening_q-graphics-in-gmt.tsv", "w")
writer = csv.writer(file)

writer.writerow(["TEXT", "USER", "META", "LINK"])
while True:
    text = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-content")
    user = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-user-name")
    meta = page_to_scrape.find_elements(By.CLASS_NAME, "discord-message-meta-items")
    links = page_to_scrape.find_elements(By.XPATH, "//a[@title='Permalink']")
    for text, user, meta, link in zip(text, user, meta, links):
        print(" <text> " + text.text + " </text> " + " \t " + " <username> " + user.text + " </username> " + " \t " + " <meta> " + meta.text + " </meta> " + " \t " + " <link> " + link.get_attribute("href") + " </link> ")
        writer.writerow([text.text, user.text, meta.text, link.get_attribute("href")])
    try:
        page_to_scrape.find_element(By.PARTIAL_LINK_TEXT, "Next").click()
    except NoSuchElementException:
        break
file.close()
